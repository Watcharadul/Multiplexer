var searchData=
[
  ['col_0',['col',['../struct_ticker_state.html#a2693c233a1195781c63e77251fb6e93a',1,'TickerState']]],
  ['coloffset_1',['colOffset',['../struct_dev_type.html#a9ffb262e6ccb78389abd291fd446c071',1,'DevType']]]
];
