var searchData=
[
  ['queuefree_0',['queueFree',['../struct_ticker_state.html#a942a4c5388669138ad9518b3e14c3cb4',1,'TickerState']]],
  ['queueused_1',['queueUsed',['../struct_ticker_state.html#a99d84731b9512a573efd4d40d1ce6b07',1,'TickerState']]]
];
