var searchData=
[
  ['endcol_0',['endCol',['../struct_ticker_state.html#ade980baf5a975237a3a8212985081beb',1,'TickerState']]]
];
